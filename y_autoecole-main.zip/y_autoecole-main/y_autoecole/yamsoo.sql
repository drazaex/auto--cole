INSERT INTO `licenses` (`type`, `label`) VALUES
	('drive', 'Permis de Conduire')
;